//////////////////////////
// DO NOT SUBMIT THIS FILE
//////////////////////////

#include "crypto.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

// useful if you want to coredump
// yourself -- see `man raise`
//#include <signal.h>

struct caesar_basic_test_expectations {
  char lower;
  char upper;
  int key;
  char * plaintext;
  char * expected_output;
};


#suite crypto_tests


#tcase arithmetic_testcase
// ^ this isn't a "real" test-case -- it's just used as an illustration
// of how test-cases are written.

#test arithmetic_works
    int m = 3;
    int n = 4;
    int expected = 7;
    int actual = m + n;
    ck_assert_int_eq(actual, expected);

//////////////////////////////////////////////////
// Uncomment the following to see AddressSanitizer
// in action:
//////////////////////////////////////////////////

#tcase deliberately_bad_testcase

#test go_out_of_bounds
    char buf[]            = "supercallifragilistic";
    const size_t buf_size = sizeof(buf)/sizeof(buf[0]);
    buf[buf_size-1]       = 'X';
    // ^ buf is now not nul-terminated
    size_t len            = strlen(buf);
    // we expect the strlen-calculated size
    // to be greater than 0.
    ck_assert_uint_gt(len, 0);


#tcase caesar_encrypt_tests

#test basic_caesar_test

  struct caesar_basic_test_expectations expectations[] = {
    { 'A', 'Z', 1,  "AZIMUTH",      "BAJNVUI" },
    { 'A', 'Z', 13, "AZIMUTH",      "NMVZHGU" },
    { 'A', 'Z', 13, "",             "" },
    { 'A', 'Z', 0,  "AZIMUTH",      "AZIMUTH"},
    { 'A', 'Z', 7,  "HELLO WORLD",  "OLSSV DVYSK"}
  };
  size_t expectations_len = sizeof(expectations) / sizeof(struct caesar_basic_test_expectations);

  for (size_t i=0; i < expectations_len; i++) {
    struct caesar_basic_test_expectations current = expectations[i];

    // we pick a large size for our output buffer; we must ensure our plaintext
    // never exceeds this.
    char cipher_text[1024] = {0};
    caesar_encrypt(current.lower, current.upper, current.key, current.plaintext, cipher_text);
    ck_assert_str_eq(cipher_text, current.expected_output);
  }
   


// vim: syntax=c :
