# CITS3007 lab 2 demo repository

This repository contains a Makefile and C code for two programs,
"factorial" and "segfault".

## Building

Build with `make`.

